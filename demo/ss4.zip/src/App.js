import logo from './logo.svg';
import './App.css';
import {StudentList} from "./components/student/StudentList";

function App() {
  return (
    <>
      <StudentList/>
      </>
  );
}

export default App;
